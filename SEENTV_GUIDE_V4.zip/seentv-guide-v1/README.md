# SEENTV Guide

Internal customer guide app for SEENTV.

- Video panduan + search
- Ayat customer + copy/share
- Share video/text specifically to WhatsApp Business
- WhatsApp Business must be logged in with the owner's 01162919092 account; the app does not force messages to the owner's own number. When sharing, WhatsApp Business opens so the owner can choose the customer.
