package com.seentv.guide;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import android.text.*;
import java.io.*;
import java.net.*;
import java.util.*;
import androidx.core.content.FileProvider;

public class MainActivity extends Activity {
    LinearLayout root, content;
    EditText search;
    ArrayList<Item> videos = new ArrayList<>();
    ArrayList<Item> texts = new ArrayList<>();
    final int purple = Color.rgb(139,92,246);
    final int dark = Color.rgb(10,10,16);
    final int panel = Color.rgb(24,24,34);
    final String WA_NUMBER = "601162919092";
    int currentTab = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        seed();
        build();
        showVideos("");
    }

    void seed() {
        addVideo("Auto Sub Melayu", "Cara Set Auto Subtitle Melayu", "Setup", "https://drive.google.com/file/d/1BuIJxe23TFbOKNUP5e9NU28biameiwEL/view?usp=drivesdk", "thumb_auto_sub");
        addVideo("Refresh Provider", "Cara Update Playlist / Provider", "Refresh", "https://drive.google.com/file/d/1Awq28eRwX3EUtUeT9w1wRolK32jy6Lo4/view?usp=drivesdk", "thumb_provider");
        addVideo("Reload Media Library", "Cara Update Media Library (Movies & Series)", "Refresh", "https://drive.google.com/file/d/1Ax7S8gJR10JpHYf-wr8izIl_-WML_YXu/view?usp=drivesdk", "thumb_media");
        addVideo("Reload EPG", "Cara Update EPG Teleguide / Intisari Rancangan", "Refresh", "https://drive.google.com/file/d/1svi5Hsttq9OQYku6qabgpu_OzyNWcT9Q/view?usp=drivesdk", "thumb_epg");
        addVideo("Clear Cache", "Cara Off Cache Pada OTT Navigator", "Troubleshoot", "https://drive.google.com/file/d/1RUu7iNLrmEkRjeJeplC9XZb4ClJMO3rA/view?usp=drivesdk", "thumb_cache");
        addVideo("Kembali Channel Hilang", "Cara Kembalikan Channel Yang Hilang", "Troubleshoot", "https://drive.google.com/file/d/1m0mmJno1cenCu18C22rFeip3EXB_0l_2/view?usp=drivesdk", "thumb_channel");
        addVideo("Kembalikan Folder Hilang", "Cara Kembalikan Folder Channel Yang Hilang / Ter-Remove", "Troubleshoot", "https://drive.google.com/file/d/1mNWlBFBK4Z-cDfsmluj75IUT-bUSPZkW/view?usp=drivesdk", "thumb_folder");
        addVideo("Delete Provider", "Cara Delete Provider Yang Tak Guna / Tak Sepatutnya Ada", "Troubleshoot", "https://drive.google.com/file/d/1sI2sniISGiEmq7H4Q1zqjPwacMsb4tHk/view?usp=drivesdk", "thumb_delete");

        texts.add(new Item("Selepas Customer Buat Payment",
            "Terima kasih membuat pembayaran. Boleh bagi saya satu username.\nCth: TVRUANGTAMU, HPSAYA, TVBILIK\n\nUsername boleh create sendiri ya.", "Customer", ""));
        texts.add(new Item("Selepas Siap Buat ID",
            "Klik link di atas untuk mengaktifkan akaun.\n\nKemudian, tekan START untuk memulakan chat dengan bot Telegram.\n\nBot Telegram akan memberikan detail akaun berserta panduan CARA ADD PROVIDER di Telegram.\n\nPada masa yang sama, saya juga akan menerima detail yang sama untuk rujukan dan pengaktifan akaun anda.", "Customer", ""));
        texts.add(new Item("Selepas Customer Siap Masukkan ID",
            "🚨 TOLONG BACA & TOLONG BUAT 🚨\n\n📌 3 JENIS REFRESH KENA BUAT 📌\n\n1️⃣ REFRESH PLAYLIST/PROVIDER (BUAT SETIAP HARI - UNTUK REFRESH CHANNEL LIVE TV)\n\n1. Klik Setting\n2. Klik Provider\n3. Tekan Button Logo Refresh ↩️\n\nSiap. Disyorkan buat selalu, setiap hari dan bila ada perubahan/maintenance pada source channel.\n\n2️⃣ REFRESH MEDIA LIBRARY (BUAT SETIAP HARI - UNTUK UPDATE MOVIES & SERIES)\n\n1. Klik Setting\n2. Klik Media Library\n3. Klik Reload Data\n\nSebaiknya buat setiap hari.\n\n3️⃣ REFRESH EPG TELEGUIDE (BUAT SETIAP HARI - UNTUK REFRESH INTISARI RANCANGAN)\n\n1. Setting\n2. Klik EPG Teleguide\n3. Tekan Reload EPG\n\nSiap.", "Customer", ""));
        texts.add(new Item("Jika Customer Belum Download OTT Navigator",
            "Cara Download APP OTT NAVIGATOR v.1.7.4.1\n\nCara 1: HP Android\nKlik je link dibawah, download pastu Install. Setting wajib Allow.\n👉 https://link2u.cc/tvtech\n\nCara 2: Android Box NON CERTIFIED (contoh: TX3, TX6, MXQ, T9 dll).\n\nBuka Google Chrome, taip link kat ruangan Web Address, bukan kat Carian:\n👉 https://link2u.cc/tvtech\n\n- Klik Go, akan terus download\n- Lepas tu, klik file yang dah download tadi, INSTALL\n- Sistem akan mintak 'Allow'. Allow kan untuk CHROME.\n- Back, Install lagi sekali.\n- SIAP\n\nCara 3: Android TV/Mi Box/Mi Stick\n1. Buka Play Store/Entertainment (Google TV)\n2. Buat carian/taip DOWNLOADER\n3. Tekan pada \"Downloader Aftv\" & Install\n4. Buka \"Downloader\" dan tekan HOME\n5. TAIP https://link2u.cc/tvtech\n6. Tekan GO\n7. Sistem akan download dan mintak install, klik INSTALL & ALLOW kan permission untuk Downloader kat setting. Klik BACK & INSTALL lagi sekali.\n8. SIAP Install. Klik DONE. Tutup app Downloader, pastu buka app OTT Navigator yang baru install tadi.", "Customer", ""));
        texts.add(new Item("Jika Customer WhatsApp Minta List Harga",
            "PAKEJ SEENTV - guna app OTT NAVIGATOR\n\nApa yang Kami Tawarkan?\n\n• 900+ Live Channel (full channel esterox)\n• 60,000+ Movies & Series (updated dan boleh request movies series)\n\nPakej SEENTV ⬇️:\n\n• PAKEJ TRIAL - RM 6/10 Hari (Trial 1x jer)\n• PAKEJ A - RM 15/30 Hari\n• PAKEJ B - RM 30/65 Hari\n• PAKEJ C - RM 45/100 Hari\n• PAKEJ D - RM 85/200 Hari\n• PAKEJ E - RM 150/400 Hari\n\nSupport Android device & Google TV sahaja.\n\n1 ID = 1 DEVICE SAHAJA", "Customer", ""));
    }

    void addVideo(String label, String title, String category, String url, String thumb) {
        Item x = new Item(title, url, category, thumb); x.label = label; videos.add(x);
    }

    void build() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,16,18,10); root.setBackgroundColor(dark); setContentView(root);

        LinearLayout header = new LinearLayout(this); header.setOrientation(LinearLayout.HORIZONTAL); header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles = new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL);
        TextView title=t("SEENTV GUIDE",26,Color.WHITE); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); titles.addView(title);
        titles.addView(t("Video Panduan • Ayat Customer",13,Color.LTGRAY));
        header.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        Button waHead = btn("💬 WhatsApp\nBusiness"); waHead.setTextSize(11); header.addView(waHead,new LinearLayout.LayoutParams(120,58));
        waHead.setOnClickListener(v->openWhatsApp(""));
        root.addView(header);

        search=new EditText(this); search.setHint("🔎  Cari video atau ayat..."); search.setSingleLine(); search.setTextColor(Color.WHITE); search.setHintTextColor(Color.GRAY); search.setPadding(16,0,16,0); search.setBackground(round(Color.rgb(28,28,38),14)); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,58); sp.setMargins(0,12,0,0); root.addView(search,sp);

        LinearLayout tabs=new LinearLayout(this); tabs.setPadding(0,10,0,10);
        Button bv=btn("🎬  VIDEO PANDUAN"), bt=btn("💬  AYAT CUSTOMER");
        tabs.addView(bv,new LinearLayout.LayoutParams(0,56,1)); tabs.addView(bt,new LinearLayout.LayoutParams(0,56,1)); root.addView(tabs);
        bv.setOnClickListener(v->{currentTab=0; styleTab(bv,true); styleTab(bt,false); showVideos(search.getText().toString());});
        bt.setOnClickListener(v->{currentTab=1; styleTab(bv,false); styleTab(bt,true); showTexts(search.getText().toString());});
        styleTab(bv,true); styleTab(bt,false);
        search.addTextChangedListener(new TextWatcher(){ public void beforeTextChanged(CharSequence s,int a,int c,int d){} public void onTextChanged(CharSequence s,int a,int b,int c){ if(currentTab==0) showVideos(s.toString()); else showTexts(s.toString()); } public void afterTextChanged(Editable e){} });

        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); ScrollView sv=new ScrollView(this); sv.setFillViewport(true); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    }

    void styleTab(Button b, boolean active){ b.setBackground(round(active?purple:Color.rgb(35,35,47),16)); b.setTextColor(Color.WHITE); }
    void showVideos(String q){ content.removeAllViews(); for(Item x:videos) if(match(x,q)) addVideoCard(x); if(content.getChildCount()==0) empty("Tiada video dijumpai."); }
    void showTexts(String q){ content.removeAllViews(); for(Item x:texts) if(match(x,q)) addText(x); if(content.getChildCount()==0) empty("Tiada ayat dijumpai."); }
    boolean match(Item x,String q){ q=q.toLowerCase(); return x.title.toLowerCase().contains(q)||x.label.toLowerCase().contains(q)||x.body.toLowerCase().contains(q); }

    void addVideoCard(Item x){
        LinearLayout c=card(); ImageView im=new ImageView(this); int res=getResources().getIdentifier(x.thumb,"drawable",getPackageName()); if(res!=0) im.setImageResource(res); im.setScaleType(ImageView.ScaleType.CENTER_CROP); LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,165); ip.setMargins(0,0,0,10); c.addView(im,ip);
        TextView cat=t("●  "+x.label,12,purple); c.addView(cat); TextView title=t(x.title,18,Color.WHITE); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); c.addView(title); c.addView(t("Panduan OTT Navigator",13,Color.LTGRAY));
        LinearLayout r=new LinearLayout(this); r.setPadding(0,8,0,0);
        Button p=btn("▶  TONTON VIDEO"), s=btn("📤  HANTAR KE WHATSAPP");
        r.addView(p,new LinearLayout.LayoutParams(0,58,1)); LinearLayout.LayoutParams ss=new LinearLayout.LayoutParams(0,58,1); ss.setMargins(8,0,0,0); r.addView(s,ss); c.addView(r);
        p.setOnClickListener(v->playRemote(x.body)); s.setOnClickListener(v->downloadAndShare(x.body,x.title)); content.addView(c);
    }

    void addText(Item x){
        LinearLayout c=card(); TextView cat=t("💬  AYAT CUSTOMER",12,purple); c.addView(cat); TextView title=t(x.title,18,Color.WHITE); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); c.addView(title); TextView b=t(x.body,14,Color.LTGRAY); b.setTextIsSelectable(true); c.addView(b);
        LinearLayout r=new LinearLayout(this); r.setPadding(0,10,0,0); Button cp=btn("📋  COPY AYAT"), sh=btn("📤  WHATSAPP BUSINESS"); r.addView(cp,new LinearLayout.LayoutParams(0,58,1)); LinearLayout.LayoutParams ss=new LinearLayout.LayoutParams(0,58,1); ss.setMargins(8,0,0,0); r.addView(sh,ss); c.addView(r);
        cp.setOnClickListener(v->{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("SEENTV",x.body)); Toast.makeText(this,"Ayat dah copy ✓",Toast.LENGTH_SHORT).show();}); sh.setOnClickListener(v->openWhatsApp(x.body)); content.addView(c);
    }

    void empty(String msg){ TextView e=t(msg,15,Color.GRAY); e.setGravity(Gravity.CENTER); e.setPadding(0,40,0,40); content.addView(e); }
    String driveId(String url){ try { int a=url.indexOf("/d/")+3; int b=url.indexOf('/',a); return url.substring(a,b); } catch(Exception e){ return url; } }
    String downloadUrl(String url){ return "https://drive.usercontent.google.com/download?id="+driveId(url)+"&export=download&confirm=t"; }
    void playRemote(String url){ try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(Exception e){ Toast.makeText(this,"Tak boleh buka video.",Toast.LENGTH_SHORT).show(); } }

    void downloadAndShare(String url,String title){
        Toast.makeText(this,"Sedang sediakan video…",Toast.LENGTH_SHORT).show();
        new Thread(() -> { try {
            URL u=new URL(downloadUrl(url)); HttpURLConnection con=(HttpURLConnection)u.openConnection(); con.setInstanceFollowRedirects(true); con.setConnectTimeout(20000); con.setReadTimeout(120000); con.connect();
            int code=con.getResponseCode(); if(code>=400) throw new IOException("HTTP "+code);
            String ct=con.getContentType(); if(ct!=null && ct.toLowerCase().contains("text/html")) throw new IOException("Drive confirmation page");
            File dir=new File(getCacheDir(),"videos"); if(!dir.exists()) dir.mkdirs(); File out=new File(dir,safe(title)+".mp4");
            InputStream in=con.getInputStream(); FileOutputStream fos=new FileOutputStream(out); byte[] buf=new byte[16384]; int n; while((n=in.read(buf))!=-1) fos.write(buf,0,n); in.close(); fos.close(); con.disconnect();
            Uri uri=FileProvider.getUriForFile(this,"com.seentv.guide.fileprovider",out); runOnUiThread(() -> shareVideoUri(uri,title));
        } catch(Exception e){ runOnUiThread(() -> Toast.makeText(this,"Video tak dapat disediakan. Pastikan Google Drive = Anyone with the link → Viewer.",Toast.LENGTH_LONG).show()); }}).start();
    }
    String safe(String s){ return s.replaceAll("[^a-zA-Z0-9._-]","_"); }

    void shareVideoUri(Uri uri,String title){
        Intent i=new Intent(Intent.ACTION_SEND); i.setType("video/mp4"); i.putExtra(Intent.EXTRA_STREAM,uri); i.putExtra(Intent.EXTRA_TEXT,title); i.putExtra("jid",WA_NUMBER+"@s.whatsapp.net"); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if(isInstalled("com.whatsapp.w4b")){ i.setPackage("com.whatsapp.w4b"); try{startActivity(i); return;}catch(Exception ignored){} }
        if(isInstalled("com.whatsapp")){ i.setPackage("com.whatsapp"); try{startActivity(i); return;}catch(Exception ignored){} }
        i.setPackage(null); startActivity(Intent.createChooser(i,"Hantar video kepada customer"));
    }

    void openWhatsApp(String text){
        try {
            String url="https://wa.me/"+WA_NUMBER;
            if(text!=null && !text.isEmpty()) url += "?text="+URLEncoder.encode(text,"UTF-8");
            Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url));
            if(isInstalled("com.whatsapp.w4b")) i.setPackage("com.whatsapp.w4b");
            startActivity(i);
        } catch(Exception e){ Toast.makeText(this,"WhatsApp Business tak dijumpai.",Toast.LENGTH_SHORT).show(); }
    }

    boolean isInstalled(String pkg){ try{ getPackageManager().getPackageInfo(pkg,0); return true; }catch(Exception e){ return false; } }
    GradientDrawable round(int color,int radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }
    LinearLayout card(){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(16,16,16,16); c.setBackground(round(panel,18)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,14); c.setLayoutParams(lp); return c; }
    TextView t(String s,float z,int col){ TextView v=new TextView(this); v.setText(s); v.setTextSize(z); v.setTextColor(col); v.setPadding(0,4,0,4); return v; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setTextSize(13); b.setGravity(Gravity.CENTER); b.setMinHeight(56); b.setPadding(8,0,8,0); b.setBackground(round(Color.rgb(54,54,70),16)); return b; }
    static class Item { String title,body,label,thumb; Item(String a,String b,String c,String d){title=a;body=b;label=c;thumb=d;} }
}
