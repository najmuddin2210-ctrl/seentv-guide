# SEENTV Guide v2

Internal Android guide app for SEENTV customer support.

Features:
- 8 video tutorials with large, easy-to-tap buttons
- 5 customer message templates
- Search videos and messages
- Copy customer messages
- WhatsApp Business shortcut to 011-62919092
- Video sharing attempts WhatsApp Business first

Videos remain on Google Drive; the APK does not embed the large video files.
