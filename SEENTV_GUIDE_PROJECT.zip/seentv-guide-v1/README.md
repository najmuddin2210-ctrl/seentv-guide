# SEENTV Guide App

Android app untuk kegunaan dalaman SEENTV.

## Fungsi
- 8 video panduan OTT Navigator
- Carian video dan ayat
- Tonton video melalui Google Drive
- Hantar fail video terus ke WhatsApp (video dimuat turun sementara ke cache)
- 5 template ayat customer
- Copy atau share ayat ke WhatsApp

## Penting
Semua video Google Drive mesti diset kepada **Anyone with the link → Viewer**.

Video tidak dimasukkan ke dalam source supaya projek kekal kecil dan mudah dibina.
